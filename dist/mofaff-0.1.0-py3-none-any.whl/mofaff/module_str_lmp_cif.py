from ase.io import read, write, vasp
import numpy as np
import fileinput

def convert_dump_cif(input_file_dump, output_file_cif):
    # Read out_sort.dump using ASE
    frames = read(input_file_dump, index=-1, format='lammps-dump-text')
    write(output_file_cif,frames)

def remove_water(filename,n_mof_o):
    # Remove all H2O molecules
    with open(filename, 'r') as file:
        lines = file.readlines()

    h_indices = [i for i, line in enumerate(lines) if ' H ' in line]
    o_indices = [i for i, line in enumerate(lines) if ' O ' in line]

    total_o = len(o_indices)
    num_o = total_o - n_mof_o
    num_h = 2*num_o

    h_indices = [i for i, line in enumerate(lines) if ' H ' in line]
    o_indices = [i for i, line in enumerate(lines) if ' O ' in line]

    h_to_remove = h_indices[-num_h:] if num_h <= len(h_indices) else h_indices
    o_to_remove = o_indices[-num_o:] if num_o <= len(o_indices) else o_indices

    indices_to_remove = set(h_to_remove + o_to_remove)
    new_lines = [line for i, line in enumerate(lines) if i not in indices_to_remove]

    with open(filename, 'w') as file:
        file.writelines(new_lines)

