import shutil
import re

def raspa_to_lmp(raspa_data,output):
    shutil.move(raspa_data, output)
    with open(output, 'r') as file:
        lines = file.readlines()

    with open(output, 'w') as file:
        between_masses_atoms = False
        atoms_section = False
        for line in lines:
            if 'Masses' in line:
                between_masses_atoms = True
                continue
            if 'Atoms' in line:
                between_masses_atoms = False
                atoms_section = True
                file.write(line)
                continue
            if between_masses_atoms:
                continue
            if not re.search(r'(bond|angle|dihedral|improper|C_co2|O_co2|N_n2|N_com|Lw|Zr|atom types)', line):
                file.write(line)

    with open(output, 'r') as file:
        lines = file.readlines()

    found_atoms_1 = False
    found_atoms_2 = False
    count_1=0
    count_2=1

    with open(output, 'w') as file:
        for line in lines:
            if 'Atoms' in line:
                found_atoms_1 = True
            if found_atoms_1 and len(line.split()) > 3:
                count_1 = count_1 + 1

        for line in lines:
            if 'atoms' in line:
                file.write(f'{count_1} atoms\n7 atom types\n')
            else:
                line = line.replace('# C', '#C 1')
                line = line.replace('# F', '#F 2')
                line = line.replace('# Nb', '#Nb 5')
                line = line.replace('# Ni', '#Ni 6 ')
                line = line.replace('# N', '#N 4')
                line = line.replace('# Hw', '#Hw 3')
                line = line.replace('# Ow', '#Ow 7')
                line = line.replace('# O', '#O 7')
                line = line.replace('# H', '#H 3')
                if 'Atoms' in line:
                    found_atoms_2 = True
                if found_atoms_2 and len(line.split()) > 3:
                    parts = line.split()
                    line = f"{count_2} {parts[-1]} {parts[4]} {parts[5]} {parts[6]} {parts[-2]}\n"
                    count_2 = count_2 + 1
                file.write(line)

