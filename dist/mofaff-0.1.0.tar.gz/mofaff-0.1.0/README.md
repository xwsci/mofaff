# MOFAFF

A package to calculate MOF adsorption with framework flexibility

## Installation

pip install mofaff


## Usage

import mofaff
mofaff.mofaff_main('path_to_input')


commands_LAMMPS = """
module load deepmd-kit/2.1.1
lmp -i in.lammps
""" # Env for LAMMPS with MLP on QUEST

commands_gRASPA = f"""
module purge
module use /hpc/software/spack_v17d2/spack/share/spack/modules/linux-rhel7-x86_64/
module load cuda/11.2.2-gcc
module load nvhpc/21.9-gcc
{raspa_path} > result
"""

## Usage

import mofaff
mofaff.mofaff_main('path_to_input')


